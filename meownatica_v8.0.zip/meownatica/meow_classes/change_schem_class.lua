local reader = require 'meownatica:read_toml'
local arbd = require 'meownatica:arbd_utils'
local container = require 'meownatica:container_class'
local meow_schem = require 'meownatica:schem_class'
local meow_change = { }
local point2 = 1

local function arbd_convert(tbl)
    local result = {}
    for i = 1, #tbl do
        result[#result + 1] = {x = tbl[i][1], y = tbl[i][2], z = tbl[i][3], id = tbl[i][4], state = {rotation = tbl[i][5][1], solid = tbl[i][5][2], replaceable = tbl[i][5][3]}}
    end
    return result
end

function meow_change:convert_schem(meownatic_load)
    meow_schem:convert(meownatic_load)
    local source = meownatic_load:gsub("%.artd$", "") .. '.arbd'
    local source1 = "meownatica:meownatics/" .. source
    local doc = arbd:read(source1)
    container:send_g(arbd_convert(doc))
    return container:get_g()
end

function meow_change:change(meownatica, change)
    if meownatica ~= false then
        local index = (point2 - 1) % reader:len() + 1
        local source1 = "meownatica:meownatics/" .. reader:schem(index)
        if reader:schem(index):find('.arbd') then
            local doc = arbd:read(source1)
            point2 = point2 + 1
            container:send_g(arbd_convert(doc))
            return container:get_g(), 0, reader:schem(index)
        elseif reader:schem(index):find('.artd') then
            point2 = point2 + 1
            return 'convert', reader:schem(index), reader:schem(index)
        end

    elseif meownatica == false and change == false then
        local index = (point2 - 1) % reader:len() + 1
        local source1 = "meownatica:meownatics/" .. reader:schem(index)
        if reader:schem(index):find('.arbd') then
            local doc = arbd:read(source1)
            container:send_g(arbd_convert(doc))
            return container:get_g(), 0, reader:schem(index)
        elseif reader:schem(index):find('.artd') then
            return 'convert', reader:schem(index), reader:schem(index)
        end
    else
        local index = 1
        point2 = 1
        local source1 = "meownatica:meownatics/" .. reader:schem(index)
        if reader:schem(index):find('.arbd') then
            print(source1)
            local doc = arbd:read(source1)
            container:send_g(arbd_convert(doc))
            return container:get_g(), 0, reader:schem(index)
        elseif reader:schem(index):find('.artd') then
            return 'convert', reader:schem(index), reader:schem(index)
        end
    end
end

return meow_change

    