local meow_build = { }

function meow_build:new()
    local o = {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function meow_build:build_reed(x, y, z, read_meowmatic)
    local point = 0
    while point <= #read_meowmatic do
        local index = (point - 1) % #read_meowmatic + 1 
        local structure = read_meowmatic[index] 
        if block_index(structure.id) ~= 0 then
            if get_block(structure.x + x, structure.y + y, structure.z + z) == 0 then
                set_block(structure.x + x, structure.y + y, structure.z + z, block_index("meownatica:meowreed"), 0, true)
            end
        end
        point = point + 1
    end
end

function meow_build:unbuild_reed(x, y, z, read_meowmatic)
    local point = 0
    while point <= #read_meowmatic do
        local index = (point - 1) % #read_meowmatic + 1 
        local structure = read_meowmatic[index]
        if block_index(structure.id) ~= 0 then
            if get_block(structure.x + x, structure.y + y, structure.z + z) == block_index("meownatica:meowreed") then
                set_block(structure.x + x, structure.y + y, structure.z + z, 0, 0, true)
            end
        end
        point = point + 1
    end
end

function meow_build:build_schem(x, y, z, read_meowmatic, set_air, blocks_update, set_block_on_tick)
    local point = 0
    local block_pack = set_block_on_tick
    if blocks_update then
        blocks_update = false
    else
        blocks_update = true
    end
    while point <= #read_meowmatic and point <= block_pack do
        local index = (point - 1) % #read_meowmatic + 1 
        local structure = read_meowmatic[index]
        if get_block(structure.x + x, structure.y + y, structure.z + z) ~= -1 and block_name(get_block(structure.x + x, structure.y + y, structure.z + z)) ~= structure.id then
            print(block_name(get_block(structure.x + x, structure.y + y, structure.z + z)), structure.id)
            if structure.id == "core:air" and set_air == true then
                set_block(structure.x + x, structure.y + y, structure.z + z, block_index(structure.id), structure.state.rotation, blocks_update)
            elseif structure.id ~= "core:air" then
                set_block(structure.x + x, structure.y + y, structure.z + z, block_index(structure.id), structure.state.rotation, blocks_update)
            else
                block_pack = block_pack + 1
            end
        end
        if get_block(structure.x + x, structure.y + y, structure.z + z) ~= -1 then
            table.remove(read_meowmatic, point)
            block_pack = set_block_on_tick
        else
            block_pack = block_pack + 1
        end
        point = point + 1
    end
    if #read_meowmatic > 0 then
        return read_meowmatic
    else
        return 'over'
    end
end

function meow_build:build_layer(x, y, z, read_meowmatic, set_air, blocks_update, layer)
    local point = 0
    if blocks_update then
        blocks_update = false
    else
        blocks_update = true
    end
    while point <= #read_meowmatic do
        local index = (point - 1) % #read_meowmatic + 1 
        local structure = read_meowmatic[index]
        if get_block(structure.x + x, structure.y + y, structure.z + z) ~= block_index("meownatica:meowoad") then
            if structure.id == "core:air" and set_air == true then
                if layer == structure.y then
                    set_block(structure.x + x, structure.y + y, structure.z + z, block_index(structure.id), structure.state.rotation, blocks_update)
                end
            else 
                if structure.id ~= "core:air" then
                    if layer == structure.y then
                        set_block(structure.x + x, structure.y + y, structure.z + z, block_index(structure.id), structure.state.rotation, blocks_update)
                    end
                end
            end
        end
        point = point + 1
    end
end

return meow_build