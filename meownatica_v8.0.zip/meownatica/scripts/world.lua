function on_world_open()
    data_meow = require 'meownatica:metadata_class'
    data_meow:open_metadata()
end