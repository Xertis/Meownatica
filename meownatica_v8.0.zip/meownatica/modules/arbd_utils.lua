local arbd = require 'meownatica:arbd'
local data_buffer = require "core:data_buffer"

local arbd_u = {}

function arbd_u:write(array, path)
    local buf = data_buffer()

    arbd.serialize(array, buf)
  
    file.write_bytes(path, buf:get_bytes())
end

function arbd_u:read(path)
    if not file.exists(path) then
        return nil
    end
    
    return arbd.deserialize(data_buffer(file.read_bytes(path)))
end

return arbd_u